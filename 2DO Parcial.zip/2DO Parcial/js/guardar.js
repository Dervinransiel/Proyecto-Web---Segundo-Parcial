function guardar(){
    db.collection("Datos del Usuario").add({
        Nombre: document.getElementById("name").value,
        Correo: document.getElementById("user").value,
        Contraseña: document.getElementById("password").value,
      
    })
    .then((docRef) => {
        //alert("registro exitoso");
        swal({
            title: "Registro Guardado!",
            text: "GRACIAS!",
            icon: "success",
            button: "OK!",
           
            
          });
    })
    .catch((error) => {
        alert("error en el registro")
    });
}