//import firebase from "firebase/app";
//import "firebase/firestore";

// TODO: Replace the following with your app's Firebase project configuration
// See: https://firebase.google.com/docs/web/learn-more#config-object
const firebaseConfig = {
    apiKey: "AIzaSyDzECKOYdTuNVrFnktnTSkSv888_OU_DVg",
    authDomain: "database-d1e9f.firebaseapp.com",
    projectId: "database-d1e9f",
    storageBucket: "database-d1e9f.appspot.com",
    messagingSenderId: "491140805613",
    appId: "1:491140805613:web:d1ba5bf7ce889e8d4fade4"
    // ...
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);



// Initialize Cloud Firestore and get a reference to the service
const db = firebase.firestore();
